/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordmanager;


public class password {
    String text;
    password1 allpasswords[];

    public password(String text, password1 passwords[]) {
        this.text = text;
        this.allpasswords = passwords;
    }
    public password1[]getpasswords(){
        return allpasswords; 
    }
    
}
class password1{
    String text;
    String email;
    int lenght;

    public password1(String text, String email, int lenght) {
        this.text = text;
        this.email = email;
        this.lenght = lenght;
    }
    
    





}