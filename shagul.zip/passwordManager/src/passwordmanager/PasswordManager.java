/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordmanager;


public class PasswordManager {

    
    public static void main(String[] args) {
       password1 w1=new password1("facebook","xuncha@gmail.com",13);
       password1 w2=new password1("instagram","shagul@gmail.com",43);
        password1 w3=new password1("snap","hamashagul@gmail.com",65);
       password1 listofpasswords[]=new password1[4];
       listofpasswords[0]=w1;
       listofpasswords[1]=w2;
       listofpasswords[2]=w3;
       listofpasswords[3]=new password1("telgram","7ajisaber@gmail.com",54);
       
       password w4=new password("write text",listofpasswords);
        for (int i = 0; i <listofpasswords.length; i++) {
            System.out.println("Site : "+listofpasswords[i].text);
             System.out.println("login our email : "+listofpasswords[i].email);
              System.out.println("login our password : "+listofpasswords[i].lenght);
              System.out.println("***************************");
            
        }
    }
    
}
